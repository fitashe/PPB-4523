package com.example.menumakananzamannow;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;

    String s1[], s2[], s3[];
    int images[] = {R.drawable.pecel_lele, R.drawable.nasgor_mercon, R.drawable.ayamgeprek_keju, R.drawable.kari_ayam, R.drawable.tahu_bulat, R.drawable.salad_buah};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        s1 = getResources().getStringArray(R.array.menu_makanan);
        s2 = getResources().getStringArray(R.array.detail);
        s3 = getResources().getStringArray(R.array.harga);

        MyAdapter myAdapter = new MyAdapter(this, s1, s2,images);
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
}
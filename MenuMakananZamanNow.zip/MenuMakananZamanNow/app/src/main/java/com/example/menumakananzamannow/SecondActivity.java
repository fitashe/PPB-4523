package com.example.menumakananzamannow;

public class SecondActivity {
}

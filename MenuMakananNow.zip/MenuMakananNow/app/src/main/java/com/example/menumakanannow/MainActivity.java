package com.example.menumakanannow;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    String menu[], detail[], harga[];
    int images[] = {R.drawable.pecel_lele, R.drawable.nasgor_mercon, R.drawable.ayamgeprek_keju, R.drawable.kari_ayam, R.drawable.tahu_bulat, R.drawable.salad_buah};

    @NonNull
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        menu = getResources().getStringArray(R.array.menu_makanan);
        detail = getResources().getStringArray(R.array.detail);
        harga = getResources().getStringArray(R.array.harga_makanan);

        MakananAdapter makananAdapter = new MakananAdapter(this, menu, detail, harga, images);
        recyclerView.setAdapter(makananAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
}
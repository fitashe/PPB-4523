package com.example.menumakanannow;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.text.BreakIterator;

public class MakananAdapter extends RecyclerView.Adapter<MakananAdapter.MyViewHolder> {

    String data1[], data2[], data3[];
    int images[];
    Context context;
    private View view;

    public MakananAdapter(Context ct, String[] strings, String[] menu, String[] detail, String[] harga, int[] img){
        context = ct;
        data1 = menu;
        data2 = detail;
        data3 = harga;
        images = img;
    }

    public MakananAdapter(MainActivity ct, String[] menu, String[] detail, String[] harga, int[] images) {
    }

    @NonNull
    @Override
    public MakananAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.my_layout, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MakananAdapter.MyViewHolder holder, int position) {
        holder.menu_makanan.setText(data1[position]);
        holder.detail.setText(data2[position]);
        holder.harga_makanan.setText(data3[position]);
        holder.myImage.setImageResource(images[position]);

        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, SecondActivity.class);
                intent.putExtra("data1", data1[position]);
                intent.putExtra("data2", data2[position]);
                intent.putExtra("data3", data3[position]);
                intent.putExtra("myImage", images[position]);
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return images.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView menu_makanan, detail, harga_makanan;
        ImageView myImage;
        ConstraintLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            menu_makanan = itemView.findViewById(R.id.menu_makanan);
            detail = itemView.findViewById(R.id.detail);
            harga_makanan = itemView.findViewById(R.id.harga);
            myImage = itemView.findViewById(R.id.myImage);

            mainLayout = itemView.findViewById(R.id.mainLayout);

        }
    }
}
